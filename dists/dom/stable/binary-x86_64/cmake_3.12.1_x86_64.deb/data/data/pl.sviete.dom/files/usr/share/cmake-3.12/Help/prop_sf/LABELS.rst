LABELS
------

Specify a list of text labels associated with a source file.

This property has meaning only when the source file is listed in a
target whose LABELS property is also set.  No other semantics are
currently specified.
