.. cmake-module:: ../../Modules/CMakeFindFrameworks.cmake
