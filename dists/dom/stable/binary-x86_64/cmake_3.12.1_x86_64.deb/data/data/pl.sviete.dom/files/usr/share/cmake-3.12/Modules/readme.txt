See the "Find Modules" section of the cmake-developer(7) manual page.

For more information about how to contribute modules to CMake, see this page:
https://gitlab.kitware.com/cmake/community/wikis/doc/cmake/dev/Module-Maintainers
