rocks_trees = {
   { name = [[user]], root = home..[[/.luarocks]] },
   { name = [[system]], root = [[/data/data/pl.sviete.dom/files/usr]] }
}
