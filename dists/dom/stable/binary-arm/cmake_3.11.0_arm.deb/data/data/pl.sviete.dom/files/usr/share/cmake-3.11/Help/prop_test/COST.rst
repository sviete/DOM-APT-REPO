COST
----

Set this to a floating point value. Tests in a test set will be run in descending order of cost.

This property describes the cost of a test.  You can explicitly set
this value; tests with higher COST values will run first.
