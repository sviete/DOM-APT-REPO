VS_SHADER_DISABLE_OPTIMIZATIONS
-------------------------------

Disable compiler optimizations for an ``.hlsl`` source file.  This adds the
``-Od`` flag to the command line for the FxCompiler tool.  Specify the value
``true`` for this property to disable compiler optimizations.
