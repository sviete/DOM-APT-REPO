#ifndef __NETWORK_OPENSSL_H
#define __NETWORK_OPENSSL_H

gboolean irssi_ssl_init(void);

#endif /* !__NETWORK_OPENSSL_H */
