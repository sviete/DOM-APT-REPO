MACROS
------

List of macro commands available in the current directory.

This read-only property specifies the list of CMake macros currently
defined.  It is intended for debugging purposes.  See the macro
command.
