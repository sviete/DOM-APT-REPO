EXTERNAL_OBJECT
---------------

If set to true then this is an object file.

If this property is set to true then the source file is really an
object file and should not be compiled.  It will still be linked into
the target though.
