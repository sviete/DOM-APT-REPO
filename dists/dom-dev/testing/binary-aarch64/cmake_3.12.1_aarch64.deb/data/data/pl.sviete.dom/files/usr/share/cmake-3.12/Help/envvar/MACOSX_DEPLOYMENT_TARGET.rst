MACOSX_DEPLOYMENT_TARGET
------------------------

Specify the minimum version of OS X on which the target binaries are
to be deployed.

The ``MACOSX_DEPLOYMENT_TARGET`` environment variable sets the default value for
the :variable:`CMAKE_OSX_DEPLOYMENT_TARGET` variable.
