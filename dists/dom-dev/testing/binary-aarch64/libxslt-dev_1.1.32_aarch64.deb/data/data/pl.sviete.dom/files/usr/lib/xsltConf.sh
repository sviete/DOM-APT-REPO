#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/data/data/pl.sviete.dom/files/usr/lib"
XSLT_LIBS="-lxslt -L/data/data/pl.sviete.dom/files/usr/lib -lxml2 -lm "
XSLT_INCLUDEDIR="-I/data/data/pl.sviete.dom/files/usr/include"
MODULE_VERSION="xslt-1.1.32"
