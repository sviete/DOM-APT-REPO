#ifndef __DCC_FILE_H
#define __DCC_FILE_H

#include "dcc.h"

typedef struct {
#include "dcc-file-rec.h"
} FILE_DCC_REC;

#endif
