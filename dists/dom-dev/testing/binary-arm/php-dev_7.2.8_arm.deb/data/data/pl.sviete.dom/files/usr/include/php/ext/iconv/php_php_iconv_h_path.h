#define PHP_ICONV_H_PATH </data/data/pl.sviete.dom/files/usr/include/iconv.h>
