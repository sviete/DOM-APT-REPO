#ifndef R_VERSION_H
#define R_VERSION_H 1
#define R2_VERSION_COMMIT 0
#define R2_VERSION "2.8.0"
#define R2_GITTAP "2.8.0"
#define R2_GITTIP "HEAD"
#define R2_BIRTH "2018-08-19__09:54:43"
#endif
