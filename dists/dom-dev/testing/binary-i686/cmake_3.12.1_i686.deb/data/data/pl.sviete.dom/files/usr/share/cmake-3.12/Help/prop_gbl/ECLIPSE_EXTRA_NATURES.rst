ECLIPSE_EXTRA_NATURES
---------------------

List of natures to add to the generated Eclipse project file.

Eclipse projects specify language plugins by using natures. This property
should be set to the unique identifier for a nature (which looks like a Java
package name).

Also see the :prop_gbl:`ECLIPSE_EXTRA_CPROJECT_CONTENTS` property.
