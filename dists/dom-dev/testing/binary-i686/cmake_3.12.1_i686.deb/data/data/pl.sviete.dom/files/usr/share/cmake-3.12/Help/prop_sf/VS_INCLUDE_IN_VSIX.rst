VS_INCLUDE_IN_VSIX
------------------

Boolean property to specify if the file should be included within a VSIX
extension package. This is needed for development of Visual Studio
extensions.
